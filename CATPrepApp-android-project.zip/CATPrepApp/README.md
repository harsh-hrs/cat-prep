# CAT Prep: Android app

Profiles (PIN optional), CAT 2026 or 2027 plan, an adaptive Today plan, daily history, the full video
library with YouTube thumbnails and an in-app player, 51 full-length mocks with analysis and
recommendations, a past-paper tracker, a mistake log and progress. Everything except video playback
works offline.

Progress is saved on the phone. YouTube links open in the YouTube app.

## Build the APK on GitHub
1. Upload this zip to your GitHub repository (Add file → Upload files → Commit).
2. The "Build APK" workflow in the Actions tab builds it (about 4 minutes).
3. Download **CAT-Prep-APK** from the finished run, unzip it, and install `app-debug.apk`.

## Install on your phone
1. Tap `app-debug.apk`. If Android asks, allow **Install unknown apps** for your Files app or browser.
2. Tap **Install**, then open **CAT Prep** from your home screen.
