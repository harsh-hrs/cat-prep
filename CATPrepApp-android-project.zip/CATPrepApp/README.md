# CAT Prep: Android app

One app with two parts, both working offline:
- **CAT Prep Library**: the sprint plan, all 99 subtopics and their videos, tracker, mock and mistake logs, progress and resources.
- **CAT mock test**: the full-length mock with analysis. Open it from Resources → Free mocks.

Progress is saved on the phone. YouTube links open in the YouTube app.

## Option A: build on GitHub (free, no software to install)
1. Create a free account at github.com and make a new repository (any name).
2. Click **Add file → Upload files** and upload everything in this folder, including the `.github` folder.
   If the `.github` folder doesn't upload, go to **Actions → set up a workflow yourself**, paste the contents of
   `.github/workflows/build-apk.yml`, and commit.
3. Open the **Actions** tab. The "Build APK" job starts by itself and takes about 3–5 minutes.
4. When it shows a green tick, open the run and download **CAT-Prep-APK** under *Artifacts*. Unzip it to get `app-debug.apk`.

## Option B: build with Android Studio
1. Open this folder in Android Studio (File → Open).
2. Let it sync, then choose **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
3. The APK is in `app/build/outputs/apk/debug/app-debug.apk`.

## Install on your phone
1. Copy `app-debug.apk` to the phone, or download it straight onto the phone.
2. Tap it. If Android asks, allow **Install unknown apps** for your browser or file manager.
3. Tap **Install**, then open **CAT Prep** from your home screen.
